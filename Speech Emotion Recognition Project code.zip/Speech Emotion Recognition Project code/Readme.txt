To run the project implement the following steps:

1) Open the project using matlab 2017Ra.

2) Run the main.m file.

3) A dailog box appears asking to choose the classifier to use.

4) Click on the desired classifier.

5) The classifier will run and generate the results and terminate (Training 
   and Testing on Polish Emotional dataset included in Atrain.xlsx sheet 3 and 4 respectively).

6) To see the results on other classifiers go to STEP:2 .


Thankyou.  